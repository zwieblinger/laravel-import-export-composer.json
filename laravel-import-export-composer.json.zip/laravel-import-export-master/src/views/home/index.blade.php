<div class="jumbotron">
  <h1>Welcome</h1>
  <p>Welcome to laravel import-export package. This software is built to import and export data from various format file to an sql database.</p>
  <p>What are you waiting for?</p>
  <p>
    <a class="btn btn-lg btn-success" href="{{URL::action('Jacopo\LaravelImportExport\ImportController@getIndex')}}">Start importing »</a>
  </p>
</div>