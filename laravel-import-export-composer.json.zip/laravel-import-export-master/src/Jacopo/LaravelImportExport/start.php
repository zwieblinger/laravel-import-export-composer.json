<?php

include_once __DIR__ . '/routes.php';