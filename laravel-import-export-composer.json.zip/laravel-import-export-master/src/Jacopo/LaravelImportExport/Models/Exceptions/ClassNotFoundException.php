<?php namespace Jacopo\LaravelImportExport\Models\Exceptions;

class ClassNotFoundException extends \Exception {}
