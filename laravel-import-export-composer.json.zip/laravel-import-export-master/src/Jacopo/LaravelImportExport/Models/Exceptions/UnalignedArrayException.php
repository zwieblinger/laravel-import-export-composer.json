<?php namespace Jacopo\LaravelImportExport\Models\Exceptions;

class UnalignedArrayException extends \Exception {}
