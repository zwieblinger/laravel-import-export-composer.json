<?php namespace Jacopo\LaravelImportExport\Models\Exceptions;

class NoDataException extends \Exception {}
