<?php namespace Jacopo\LaravelImportExport\Models\Exceptions;

class HeadersNotSetException extends \Exception {}
