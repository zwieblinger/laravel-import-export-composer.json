<?php namespace Jacopo\LaravelImportExport\Models\Exceptions;

class FileNotFoundException extends \Exception {}
