<?php namespace Jacopo\LaravelImportExport\Models\StateHandling;
/**
 * Simple ArrayIterator of States
 *
 * @author Jacopo Beschi <beschi.jacopo@gmail.com>
 */

use \ArrayIterator;

class StateArray extends ArrayIterator {}
