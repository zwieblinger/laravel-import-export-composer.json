<?php

return array(
	"table_prefix" => "_import_export_temporary_table",
	"default_title" => "Laravel-Import-Export",
	"session_import_key" => "import_state",
	"session_export_key" => "export_state",
	"base_application_route" => "importer",
   "connection_name" => "import",
);